<?php

class TSZF_Edit_Profile {

    function __construct() {

        add_action( 'personal_options_update', array($this, 'post_lock_update') );
        add_action( 'edit_user_profile_update', array($this, 'post_lock_update') );

        add_action( 'show_user_profile', array($this, 'post_lock_form') );
        add_action( 'edit_user_profile', array($this, 'post_lock_form') );
    }

    /**
     * Builds frontend dashboard.
     *
     * @author Tareq Hasan
     */
    function build() {

        ob_start();

        if ( is_user_logged_in() ) {
            $this->show_form();
        } else {
            printf( __( "This page is restricted. Please %s to view this page.", 'gowatch' ), wp_loginout( '', false ) );
        }

        $content = ob_get_contents();
        ob_end_clean();

        return $content;
    }

    /**
     * Shows the user profile form
     *
     * @global type $userdata
     * @param type $user_id
     */
    function show_form( $user_id = null ) {
        global $userdata, $wp_http_referer;
        wp_get_current_user();

        if ( !(function_exists( 'get_user_to_edit' )) ) {
            require_once(ABSPATH . '/wp-admin/includes/user.php');
        }

        if ( !(function_exists( '_wp_get_user_contactmethods' )) ) {
            require_once(ABSPATH . '/wp-includes/registration.php');
        }

        if ( !$user_id ) {
            $current_user = wp_get_current_user();
            $user_id = $user_ID = $current_user->ID;
        }

        if ( isset( $_POST['submit'] ) ) {
            check_admin_referer( 'update-profile_' . $user_id );
            $errors = edit_user( $user_id );
            if ( is_wp_error( $errors ) ) {
                $message = $errors->get_error_message();
                $style = 'error airkit_alert alert-danger';
            } else {
                $message = __( '<strong>Success</strong>: Profile updated', 'gowatch' );
                $style = 'success airkit_alert alert-success';
                do_action( 'personal_options_update', $user_id );
            }
        }

        $profileuser = get_user_to_edit( $user_id );

        if ( isset( $message ) ) {
            echo '<div class="' . $style . '">' . $message . '</div>';
        }
        ?>
        <div class="tszf-profile row">
            <form name="profile" id="your-profile" action="" method="post" enctype="multipart/form-data">
                <?php wp_nonce_field( 'update-profile_' . $user_id ) ?>
                <?php if ( $wp_http_referer ) : ?>
                    <input type="hidden" name="wp_http_referer" value="<?php echo esc_url( $wp_http_referer ); ?>" />
                <?php endif; ?>
                <?php if ( is_admin_bar_showing() ): ?>
                    <input type="hidden" name="admin_bar_front" value="1"/>
                <?php endif ?>
                <input type="hidden" name="from" value="profile" />
                <input type="hidden" name="checkuser_id" value="<?php echo airkit_var_sanitize( $user_id, 'esc_attr' ); ?>" />
                <table class="tszf-table">
                    <?php do_action( 'personal_options', $profileuser ); ?>
                </table>
                <?php do_action( 'profile_personal_options', $profileuser ); ?>

                <!-- Name fieldset -->
                <fieldset class="col-lg-4">
                    <legend><?php _e( 'Name', 'gowatch' ) ?></legend>

                    <ul class="tszf-form">
                        <li>
                            <div class="tszf-label">
                                <label for="user_login1"><?php _e( 'Username', 'gowatch' ); ?></label>
                            </div>
                            <div class="tszf-fields">
                                <input type="text" name="user_login" id="user_login1" value="<?php echo esc_attr( $profileuser->user_login ); ?>" disabled="disabled" class="regular-text" />
                            </div>
                            <div class="tszf-description">
                                <?php _e( 'Usernames cannot be changed.', 'gowatch' ); ?>
                            </div>
                        </li>                        

                        <li>
                            <div class="tszf-label">
                                <label for="first_name"><?php _e( 'First Name', 'gowatch' ); ?></label>
                            </div>
                            <div class="tszf-fields">
                                <input type="text" name="first_name" id="first_name" value="<?php echo esc_attr( $profileuser->first_name ) ?>" class="regular-text" />
                            </div>
                        </li>                          

                        <li>
                            <div class="tszf-label">
                                <label for="last_name"><?php _e( 'Last Name', 'gowatch' ); ?></label>
                            </div>
                            <div class="tszf-fields">
                                <input type="text" name="last_name" id="last_name" value="<?php echo esc_attr( $profileuser->last_name ) ?>" class="regular-text" />
                            </div>
                        </li> 

                        <li>
                            <div class="tszf-label">
                                <label for="nickname"><?php _e( 'Nickname', 'gowatch' ); ?> <span class="description"><?php _e( '(required)', 'gowatch' ); ?></span></label>
                            </div>
                            <div class="tszf-fields">
                                <input type="text" name="nickname" id="nickname" value="<?php echo esc_attr( $profileuser->nickname ) ?>" class="regular-text" />
                            </div>
                        </li> 

                        <li>
                            <div class="tszf-label">
                                <label for="display_name"><?php _e( 'Display to Public as', 'gowatch' ) ?></label>
                            </div>
                            <div class="tszf-fields">
                                <select name="display_name" id="display_name">
                                    <?php
                                    $public_display = array();
                                    $public_display['display_username'] = $profileuser->user_login;
                                    $public_display['display_nickname'] = $profileuser->nickname;

                                    if ( !empty( $profileuser->first_name ) ){

                                        $public_display['display_firstname'] = $profileuser->first_name;

                                    }

                                    if ( !empty( $profileuser->last_name ) ){

                                        $public_display['display_lastname'] = $profileuser->last_name;

                                    }

                                    if ( !empty( $profileuser->first_name ) && !empty( $profileuser->last_name ) ) {

                                        $public_display['display_firstlast'] = $profileuser->first_name . ' ' . $profileuser->last_name;
                                        $public_display['display_lastfirst'] = $profileuser->last_name . ' ' . $profileuser->first_name;

                                    }

                                    if ( !in_array( $profileuser->display_name, $public_display ) ){

                                        $public_display = array('display_displayname' => $profileuser->display_name) + $public_display;

                                    }

                                    $public_display = array_map( 'trim', $public_display );
                                    $public_display = array_unique( $public_display );

                                    foreach ($public_display as $id => $item) {
                                        ?>
                                        <option id="<?php echo airkit_var_sanitize( $id, 'esc_attr' ); ?>" value="<?php echo esc_attr( $item ); ?>"<?php selected( $profileuser->display_name, $item ); ?>><?php echo airkit_var_sanitize( $item, 'esc_attr' ); ?></option>
                                        <?php
                                    }
                                    ?>
                                </select>
                            </div>
                        </li> 

                    </ul>
                </fieldset>
                <!-- END Name fieldset -->


                <!-- Contact info fieldset -->
                <fieldset class="col-lg-4">
                    <legend><?php _e( 'Contact Info', 'gowatch' ); ?></legend>

                    <ul class="tszf-form">
                        <li>
                            <div class="tszf-label">
                                <label for="email"><?php _e( 'E-mail', 'gowatch' ); ?> <span class="description"><?php _e( '(required)', 'gowatch' ); ?></span></label>
                            </div>
                            <div class="tszf-fields">
                                <input type="text" name="email" id="email" value="<?php echo esc_attr( $profileuser->user_email ) ?>" class="regular-text" />
                            </div>
                        </li>                         
                        <li>
                            <div class="tszf-label">
                                <label for="url"><?php _e( 'Website', 'gowatch' ); ?></label>
                            </div>
                            <div class="tszf-fields">
                                <input type="text" name="url" id="url" value="<?php echo esc_attr( $profileuser->user_url ) ?>" class="regular-text code" />
                            </div>
                        </li>    

                        <?php
                        foreach (_wp_get_user_contactmethods() as $name => $desc) {
                            ?>
                            <li>
                                <div class="tszf-label">
                                    <label for="<?php echo airkit_var_sanitize( $name, 'esc_attr' ); ?>"><?php echo apply_filters( 'user_' . $name . '_label', $desc ); ?></label>
                                </div>
                                <div class="tszf-fields">
                                    <input type="text" name="<?php echo airkit_var_sanitize( $name, 'esc_attr' ); ?>" id="<?php echo airkit_var_sanitize( $name, 'esc_attr' ); ?>" value="<?php echo esc_attr( $profileuser->$name ) ?>" class="regular-text" />
                                </div>
                            </li>                             
                            <?php
                        }
                        ?>                                             
                    </ul>

                </fieldset>
                <!-- END Contact info fieldset -->

                <!-- About yourself fieldset -->                
                <fieldset class="col-lg-4">
                    <legend><?php _e( 'About Yourself', 'gowatch' ); ?></legend>

                    <ul class="tszf-form">

                        <li>
                            <div class="tszf-label">
                                <label for="description"><?php _e( 'Biographical Info', 'gowatch' ); ?></label>
                            </div>
                            <div class="tszf-fields">
                                <textarea name="description" id="description" rows="5" cols="30"><?php echo esc_html( $profileuser->description ); ?></textarea>
                            </div>
                            <div class="tszf-description">
                                <?php _e( 'Share a little biographical information to fill out your profile. This may be shown publicly.', 'gowatch' ); ?>
                            </div>
                        </li> 

                        <li id="password">
                            <div class="tszf-label">
                                <label for="pass1"><?php _e( 'New Password', 'gowatch' ); ?></label>
                            </div>
                            <div class="tszf-fields">
                                <input type="password" name="pass1" id="pass1" size="16" value="" autocomplete="off" />
                            </div>
                        </li> 

                        <li>
                            <div class="tszf-label">
                                <label><?php _e( 'Confirm Password', 'gowatch' ); ?></label>
                            </div>
                            <div class="tszf-fields">
                                <input type="password" name="pass2" id="pass2" size="16" value="" autocomplete="off" />
                            </div>
                            <div class="tszf-description">
                                <?php _e( "Type your new password again.", "gowatch" ); ?>
                            </div>
                        </li>  

                        <li>
                            <div class="tszf-label">
                                <label><?php _e( 'Password Strength', 'gowatch' ); ?></label>
                            </div>
                            <div class="tszf-fields">
                                <div id="pass-strength-result"><?php _e( 'Strength indicator', 'gowatch' ); ?></div>
                                <script src="<?php echo site_url(); ?>/wp-includes/js/zxcvbn.min.js"></script>
                                <script src="<?php echo admin_url(); ?>/js/password-strength-meter.js"></script>
                                <script type="text/javascript">
                                    var pwsL10n = {
                                        empty:   "<?php echo esc_html__( 'Strength indicator', 'gowatch'); ?>",
                                        short:   "<?php echo esc_html__( 'Very weak', 'gowatch'); ?>",
                                        bad:     "<?php echo esc_html__( 'Weak', 'gowatch'); ?>",
                                        good:    "<?php echo esc_html__( 'Medium', 'gowatch'); ?>",
                                        strong:  "<?php echo esc_html__( 'Strong', 'gowatch'); ?>",
                                        mismatch:"<?php echo esc_html__( 'Mismatch', 'gowatch'); ?>"
                                    };
                                    try{convertEntities(pwsL10n);}catch(e){};
                                </script>
                            </div>
                        </li>                                                

                    </ul>

                </fieldset>
                <!-- END About yourself fieldset -->

                <!-- Custom options added with show_user_profile action. -->                
                <fieldset class="col-lg-12">
                    <?php do_action( 'show_user_profile', $profileuser ); ?>    
                </fieldset>
                <!-- END Custom profile fields .-->                

                <div class="submit col-lg-12">
                    <input type="hidden" name="action" value="update" />
                    <input type="hidden" name="user_id" id="user_id" value="<?php echo esc_attr( $user_id ); ?>" />
                    <input type="submit" class="tszf-submit" value="<?php _e( 'Update Profile', 'gowatch' ); ?>" name="submit" />
                </div>
            </form>
        </div>
        <?php
    }

    /**
     * Adds the postlock form in users profile
     *
     * @param object $profileuser
     */
    function post_lock_form( $profileuser ) {
        global $tszf_subscription;

        if ( is_admin() && current_user_can( 'edit_users' ) ) {
            $select = ( $profileuser->tszf_postlock == 'yes' ) ? 'yes' : 'no';
            ?>

            <h3><?php _e( 'TSZF Post Lock', 'gowatch' ); ?></h3>
            <table class="form-table">
                <tr>
                    <th><label for="post-lock"><?php _e( 'Lock Post:', 'gowatch' ); ?> </label></th>
                    <td>
                        <select name="tszf_postlock" id="post-lock">
                            <option value="no"<?php selected( $select, 'no' ); ?>>No</option>
                            <option value="yes"<?php selected( $select, 'yes' ); ?>>Yes</option>
                        </select>
                        <span class="description"><?php _e( 'Lock user from creating new post.', 'gowatch' ); ?></span></em>
                    </td>
                </tr>

                <tr>
                    <th><label for="post-lock"><?php _e( 'Lock Reason:', 'gowatch' ); ?> </label></th>
                    <td>
                        <input type="text" name="tszf_lock_cause" id="tszf_lock_cause" class="regular-text" value="<?php echo esc_attr( $profileuser->tszf_lock_cause ); ?>" />
                    </td>
                </tr>
            </table>

            <?php
            if ( tszf_get_option( 'charge_posting', 'tszf_payment', 'no' ) == 'yes' ) {
                $validity = (isset( $profileuser->tszf_sub_validity )) ? $profileuser->tszf_sub_validity : date( 'Y-m-d G:i:s', time() );
                $count = ( isset( $profileuser->tszf_sub_pcount ) ) ? $profileuser->tszf_sub_pcount : 0;

                if ( isset( $profileuser->tszf_sub_pack ) ) {
                    $pack = $tszf_subscription->get_subscription( $profileuser->tszf_sub_pack );
                    $pack = $pack->name;
                } else {
                    $pack = 'Free';
                }
                ?>

                <h3><?php _e( 'TSZF Subscription', 'gowatch' ); ?></h3>

                <table class="form-table">
                    <tr>
                        <th><label for="post-lock"><?php _e( 'Pack:', 'gowatch' ); ?> </label></th>
                        <td>
                            <input type="text" disabled="disabled" name="tszf_sub_pack" id="tszf_sub_pack" class="regular-text" value="<?php echo airkit_var_sanitize( $pack, 'true' ); ?>" />
                        </td>
                    </tr>
                    <tr>
                        <th><label for="post-lock"><?php _e( 'Post Count:', 'gowatch' ); ?> </label></th>
                        <td>
                            <input type="text" name="tszf_sub_pcount" id="tszf_sub_pcount" class="regular-text" value="<?php echo airkit_var_sanitize( $count, 'true' ); ?>" />
                        </td>
                    </tr>
                    <tr>
                        <th><label for="post-lock"><?php _e( 'Validity:', 'gowatch' ); ?> </label></th>
                        <td>
                            <input type="text" name="tszf_sub_validity" id="tszf_sub_validity" class="regular-text" value="<?php echo airkit_var_sanitize( $validity, 'true' ); ?>" />
                        </td>
                    </tr>
                </table>

            <?php } ?>

            <?php
        }
    }

    /**
     * Update user profile lock
     *
     * @param int $user_id
     */
    function post_lock_update( $user_id ) {
        if ( is_admin() && current_user_can( 'edit_users' ) ) {
            update_user_meta( $user_id, 'tszf_postlock', $_POST['tszf_postlock'] );
            update_user_meta( $user_id, 'tszf_lock_cause', $_POST['tszf_lock_cause'] );
            update_user_meta( $user_id, 'tszf_sub_validity', $_POST['tszf_sub_validity'] );
            update_user_meta( $user_id, 'tszf_sub_pcount', $_POST['tszf_sub_pcount'] );
        }
    }

}
