<?php get_header(); ?>

<div id="main" class="row">
	<div class="container">
		<div class="row">
			<?php echo airkit_Compilator::archive( 'blog' ); ?>
		</div>
	</div>
</div>

<?php get_footer(); ?>